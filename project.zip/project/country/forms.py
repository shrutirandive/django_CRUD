from django import forms
from country.models.country import Country
class CountryForm(forms.ModelForm):  
    class Meta:  
        model = Country  
        fields = "__all__"  