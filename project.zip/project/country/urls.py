from django.contrib import admin
from django.urls import path

from .views.create import Create
from .views.display import display
from .views.destroy import destroy
from .views.search import search

urlpatterns=[
    path('', Create.as_view(), name='create'),
    path('display',display,name='display'),
    path('destroy/<int:id>', destroy, name='destroy'),
    path('search',search, name='search'),

]