from django.shortcuts import render, redirect
from django.views import View

from country.models.country import Country

#VIEWS
def display(request):
    country=Country.objects.all()
    return render(request, 'display.html', {'country':country})