from django.shortcuts import render, redirect
from django.views import View
from django.db.models import Q
from country.models.country import Country

#VIEWS
def search(request):
    if request.method =='GET':
        query=request.GET.get('q')

        submitbutton=request.GET.get('submit')

        if query is not None:
            search=Q(name__icontains=query)
            results=Country.objects.filter(search).distinct()
            context={'results':results, 'submitbutton':submitbutton}

            return render(request, 'search.html', context)
        else:
            return render(request, 'search.html')
    else:
        return render(request, 'search.html')
