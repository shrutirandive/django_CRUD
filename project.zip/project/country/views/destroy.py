from django.shortcuts import render, redirect
from django.views import View

from country.models.country import Country

#VIEWS

def destroy(request, id):
    c=Country.objects.get(id=id)
    c.delete()
    return redirect('/display')