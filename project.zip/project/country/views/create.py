import requests
import json
from django.shortcuts import render, redirect
from django.views import View

from country.models.country import Country

# Create your views here.
# View-->class-based view 
class Create(View):
    def get(self, request):
        return render(request, 'create.html')

    def post(self, request):
        name=request.POST.get('name')
        code=request.POST.get('code')
        capital=request.POST.get('capital')
        population=request.POST.get('population')
        
        #validation
        value={
            'name':name,
            'code':code,
            'capital':capital,
            'population':population
            }

        error_message=None

        #creating objects
        country=Country(name=name, code=code, capital=capital, population=population)
        error_message=self.validateCountry(country)

        if error_message:
            data={'error': error_message, 'values':value}
            return render(request, 'create.html', data)
        else:
            print(name, capital)
            country.saveCountry()
            return redirect('/display')
        
    def validateCountry(self, country):
        error_message=None
        if(not country.name):
            error_message="enter name"
        elif(not country.code):
            error_message="enter country code"
        elif(not country.capital):
            error_message="enter capital"
        elif(not country.population):
            error_message="enter population"
            
        return error_message