CRUD operations 

Country names are arranged in alphabetical order as soon as we add them
code is uppercase
search option for captial and country
population can be represented in billions(in words)
